
#include <Wire.h>
#include <LiquidCrystal.h>
LiquidCrystal lcd(12, 11, 5, 4, 3, 2); 
const int WORDS = 101;
const int SEENWORDS = 100;
const int SB = 9;
const int BP = 10;
const int NB = 8;
int randomword = 0;
bool NBpressed = false;
bool SBpressed = false;
bool alreadyseen = false;
bool decisiontime = false;
int indexcounter = 0;
const char* chosenword = "";
const char* seenwords [SEENWORDS] = { 
  "", "", "", "", "", "", "", "", "", "",
  "", "", "", "", "", "", "", "", "", "", 
  "", "", "", "", "", "", "", "", "", "",
  "", "", "", "", "", "", "", "", "", "", 
  "", "", "", "", "", "", "", "", "", "",
  "", "", "", "", "", "", "", "", "", "", 
  "", "", "", "", "", "", "", "", "", "",
  "", "", "", "", "", "", "", "", "", "", 
  "", "", "", "", "", "", "", "", "", "",
  "", "", "", "", "", "", "", "", "", "" 
};


const char* words [WORDS] = { "barley", "cabbage", "tamarind", "lime", "wheat", "rosemary", "pomegranate",
                 "cinnamon", "currant", "banana", "pasta", "prune", "cucumber", "yogurt", "cantaloupe",
                             "corn", "artichoke", "quinoa", "guava", "salt", "spinach", "plum", "honeydew", "apple",
                             "broccoli", "kiwi", "potato", "mango", "yuzu", "blueberry", "ugli", "onion", "kale", "persimmon",
                             "honey", "mulberry", "peas", "bread", "grapefruit", "papaya", "asparagus", "lychee", "mint", "cranberry",
                             "clove", "orange", "squash", "tangerine", "quince", "eggplant", "dragonfruit", "fig", "sage", "cheese", "pepper",
                             "elderberry", "sugar", "radish", "lemon", "grape", "pear", "watermelon", "gooseberry", "avocado", "rice", "beans",
                             "zucchini", "rhubarb", "chickpeas", "lettuce", "tomato", "strawberry", "cauliflower", "garlic", "date", "dill", "yam",
                             "milk", "celery", "cherry", "okra", "ginger", "thyme", "parsley", "cilantro", "raspberry", "peach", "nectarine", "passionfruit",
                             "pomelo", "turnip", "olive", "carrot", "apricot", "mandarin", "noodle", "lentils", "starfruit", "cream", "butter"
                            };
int SeenWordsIndex = 0;

void setup() {
  Serial.begin(9600);
  randomSeed(analogRead(A0));
  lcd.begin(16, 2);
  pinMode(SB, INPUT_PULLUP);
  pinMode(NB, INPUT_PULLUP);
  pinMode(BP, OUTPUT); 

      
  pinMode(LED_BUILTIN, OUTPUT);
}

void wait() {
  SBpressed = false;
  NBpressed = false;
  while (digitalRead(NB) == HIGH && digitalRead(SB) == HIGH) {
    delay(5);
  }
  
  decisiontime = true;
  controls();
  while (digitalRead(NB) == LOW || digitalRead(SB) == LOW) {
    delay(5);
  }
}



void controls() {
  if (digitalRead(NB) == LOW) {
    NBpressed = true;
  }
  if (digitalRead(SB) == LOW) {
    SBpressed = true;
  }
}



void loop()
{
  decisiontime = false;
  alreadyseen = false;
  NBpressed = false;
  SBpressed = false;
  randomword = random(0, WORDS);
  
  chosenword = words[randomword];
  
  lcd.print(words[randomword]);
  for (int i = 0; i < SeenWordsIndex; i++) {
    if (strcmp(seenwords[i], chosenword) == 0) {
          
        alreadyseen = true;
        break;
    }
  }
            
  
  wait();
  if (decisiontime == true) {
  
  	if (NBpressed == true || SBpressed == true) {
  		if (NBpressed == true && alreadyseen == true){
    		lcd.clear();
    		lcd.print("game over");
          	tone(BP, 1000);
          	delay(500);
          	noTone(BP);
  		}
  		else if (SBpressed == true && alreadyseen == false){
    		lcd.clear();
    		lcd.print("game over");
          	tone(BP,1000);
          	delay(500);
          	noTone(BP);
  		}
      	else if ((NBpressed == true && alreadyseen == false) || (SBpressed == true && alreadyseen == true)){
          	lcd.clear();
          	lcd.print("Correct!");
          	tone(BP,290);
          	delay(1000);
          	noTone(BP);
          	lcd.clear();
  			lcd.print("Streak: ");
          	lcd.print(indexcounter + 1);
          	delay(1000);
          	lcd.clear();
          	if (alreadyseen == false) {
  				for (int transferCount = 0; transferCount < 1; transferCount++) {
    				if (SeenWordsIndex < SEENWORDS) {
      					seenwords[SeenWordsIndex] = words[randomword];
      					SeenWordsIndex++;
                      	indexcounter++;
    					}
  				
                }
            }
          	return;
        }
      	delay(1000);
  		lcd.clear();
      	indexcounter = 0;
        SeenWordsIndex = 0;
    	}      
    
  }
}
