void Sbutton() {      
    int playerguess = 0;      
    bool g = false;      

    if (PlayerTime == true) {               
        if (digitalRead(YB) == LOW) {              
            g = true;              
            playerguess = 4;              
            digitalWrite(LED_PINY, HIGH); tone(BP, 440); delay(300); noTone(BP); digitalWrite(LED_PINY, LOW);          
        }               
        else if (digitalRead(BB) == LOW) {              
            g = true;              
            playerguess = 2;              
            digitalWrite(LED_PINB, HIGH); tone(BP, 330); delay(300); noTone(BP); digitalWrite(LED_PINB, LOW);          
        }               
        else if (digitalRead(RB) == LOW) {              
            g = true;              
            playerguess = 1;        
            digitalWrite(LED_PINR, HIGH); tone(BP, 262); delay(300); noTone(BP); digitalWrite(LED_PINR, LOW);          
        }               
        else if (digitalRead(GB) == LOW) {              
            g = true;              
            playerguess = 3;              
            digitalWrite(LED_PING, HIGH); tone(BP, 392); delay(300); noTone(BP); digitalWrite(LED_PING, LOW);          
        }               

        if (g == true) {       
            if (playerguess == (int)priorOutputs[playerstep]) {                
                playerstep++;                
                g = false;                       
                
                if (playerstep == outputCount) {                  
                    PlayerTime = false;                
                    playerstep = 0; 
                    delay(1000); 
                }       
            }        
            else {                
                Serial.println("GAME OVER");                
                g = false;                
                outputCount = 0;                
                playerstep = 0;                
                PlayerTime = false;                       
                
                // Game over buzzer sound & light flash animation
                for(int i = 0; i < 3; i++) {
                    digitalWrite(LED_PINR, HIGH); digitalWrite(LED_PINB, HIGH);         
                    digitalWrite(LED_PING, HIGH); digitalWrite(LED_PINY, HIGH);         
                    tone(BP, 150); // Low error buzz
                    delay(300);         
                    digitalWrite(LED_PINR, LOW);  digitalWrite(LED_PINB, LOW);         
                    digitalWrite(LED_PING, LOW);  digitalWrite(LED_PINY, LOW);
                    noTone(BP);
                    delay(200);
                }
                delay(1000); 
            }     
        }   
    }  
}
