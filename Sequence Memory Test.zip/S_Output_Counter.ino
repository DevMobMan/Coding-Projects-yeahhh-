void saveOutput(int roundWinner) {  
  // FIXED: Changed boundary check from 10 to match your actual OUTPUT_CAP array size (5)
  if (outputCount < OUTPUT_CAP) {    
    priorOutputs[outputCount] = roundWinner; 
    Serial.print("Saved at index: ");    
    Serial.println(outputCount);    
    outputCount++; 
  } // FIXED: Added missing closing curly brace
  else {    
    Serial.println("Full"); 
  }
}
