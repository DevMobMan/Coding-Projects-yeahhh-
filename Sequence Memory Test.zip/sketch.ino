const int OUTPUT_CAP = 20;  
float priorOutputs[OUTPUT_CAP];  
int outputCount = 0;  
int playerstep = 0;  

// Button Pins
const int GB = 2;  
const int YB = 6;  
const int RB = 4;  
const int BB = 5;  

// LED Pins
const int LED_PINY = 9;  
const int LED_PINB = 11;  
const int LED_PINR = 12;  
const int LED_PING = 10;  

// Buzzer Pin Setup
const int BP = 7; // Added Buzzer Pin assignment

bool PlayerTime = false;  

// Function Prototypes
int chooseNewWinner();  
void saveOutput(int winner);  
void Sbutton();  

void setup() {     
    Serial.begin(9600);     
    randomSeed(analogRead(A0));     
    pinMode(LED_PINB, OUTPUT);     
    pinMode(LED_PINY, OUTPUT);     
    pinMode(LED_PING, OUTPUT);     
    pinMode(LED_PINR, OUTPUT);     
    pinMode(BP, OUTPUT); // Added Buzzer output declaration
    pinMode(GB, INPUT_PULLUP);     
    pinMode(YB, INPUT_PULLUP);     
    pinMode(BB, INPUT_PULLUP);     
    pinMode(RB, INPUT_PULLUP);     
} 

void loop() {     
    if (PlayerTime == false) { 
        // 1. Playback the prior sequence with your custom tone logic
        for (int i = 0; i < outputCount; i++) {             
            if (priorOutputs[i] == 1) {                 
                digitalWrite(LED_PINR, HIGH); tone(BP, 262); delay(500); noTone(BP); digitalWrite(LED_PINR, LOW); delay(900);             
            }             
            else if (priorOutputs[i] == 2) {                 
                digitalWrite(LED_PINB, HIGH); tone(BP, 330); delay(500); noTone(BP); digitalWrite(LED_PINB, LOW); delay(900);             
            }             
            else if (priorOutputs[i] == 3) {                 
                digitalWrite(LED_PING, HIGH); tone(BP, 392); delay(500); noTone(BP); digitalWrite(LED_PING, LOW); delay(900);             
            }             
            else if (priorOutputs[i] == 4) {                 
                digitalWrite(LED_PINY, HIGH); tone(BP, 440); delay(500); noTone(BP); digitalWrite(LED_PINY, LOW); delay(900);             
            } 
        }              
        
        // 2. Add a new step to the sequence and play it out
        int roundWinner = chooseNewWinner();         
        if (roundWinner == 1) {             
            digitalWrite(LED_PINR, HIGH); tone(BP, 262); delay(500); noTone(BP); digitalWrite(LED_PINR, LOW);         
        }         
        else if (roundWinner == 2) {             
            digitalWrite(LED_PINB, HIGH); tone(BP, 330); delay(500); noTone(BP); digitalWrite(LED_PINB, LOW);         
        }         
        else if (roundWinner == 3) {             
            digitalWrite(LED_PING, HIGH); tone(BP, 392); delay(500); noTone(BP); digitalWrite(LED_PING, LOW);         
        }         
        else if (roundWinner == 4) {             
            digitalWrite(LED_PINY, HIGH); tone(BP, 440); delay(500); noTone(BP); digitalWrite(LED_PINY, LOW);         
        }         
        
        saveOutput(roundWinner);         
        delay(500);         
        PlayerTime = true; 
    } else {         
        Sbutton();    
    }  
}
