// Generates 4 random numbers and returns the ID (1-4) of the highest one


int chooseNewWinner() {


 // Generate 4 fresh random numbers between 1 and 100
   int num1 = random(1, 401);
   int num2 = random(1, 401);
   int num3 = random(1, 401);
   int num4 = random(1, 401);


 // Print the current round's numbers to track them


 // Determine which one is the largest
   int winnerID = 1;
   if (num1 > num2 && num1 > num3 && num1 > num4) { winnerID = 1; }
   if (num2 > num1 && num2 > num3 && num2 > num4) { winnerID = 2; }
   if (num3 > num2 && num3 > num1 && num3 > num4) { winnerID = 3; }
   if (num4 > num1 && num4 > num2 && num4 > num3) { winnerID = 4; }
   Serial.println(num1);
   Serial.println(num2);
   Serial.println(num3);
   Serial.println(num4);
   Serial.println(winnerID);
   return winnerID;
}
