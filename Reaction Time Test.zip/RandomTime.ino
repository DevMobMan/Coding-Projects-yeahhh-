void RT() {
  if (PlayerTimeYeah == false) {
    stasis();
    unsigned long WS = millis();
    unsigned long RI = random(2000,7000);
    PM = millis();
    CM = millis();
    while (CM - PM < RI) {
    
      CM = millis();
      delay(1);
    } 
    if (CM - PM >= RI) {
      PlayerTimeYeah = true;
    }
  }
}