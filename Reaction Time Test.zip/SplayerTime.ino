void PlayerTime() {
  if (Screen == false) {
    tft.setCursor(30, 50);
    tft.setTextColor(ILI9341_WHITE, ILI9341_GREEN);
    tft.setTextSize(4);
    tft.println("PRESS!");
    startTime = millis();
    Screen = true;
  }
  while (digitalRead(butt) == LOW) {
    delay(1); 
  }


  if (digitalRead(butt) == LOW) {
    Screen = true;
    endTime = millis();
    gone = true;
    duration = endTime - startTime;
    if (gone == true) {
      startTime = millis();
      gone = false;
    }

    tft.fillRect(0, 0, 500, 520, ILI9341_BLUE); 
    tft.setCursor(70, 70);
    tft.setTextColor(ILI9341_WHITE, ILI9341_BLUE);
    tft.setTextSize(3);
    tft.println(duration);
    tft.setCursor(70, 100);
    tft.println("milliseconds");
  }
} 