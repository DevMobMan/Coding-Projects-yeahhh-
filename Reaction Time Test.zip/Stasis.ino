void stasis() {
  tft.fillScreen(ILI9341_GREEN);
  tft.drawRect(10, 10, 300, 220, ILI9341_GREEN);
  tft.setCursor(70, 50);
  tft.setTextColor(ILI9341_WHITE);
  tft.setTextSize(2);
  tft.println("Waiting...");
}