void Start() {
  if (Started == false) {
    tft.setCursor(70, 50);
    tft.setTextColor(ILI9341_BLUE);
    tft.setTextSize(2);
    tft.println("Reaction Memory");
    tft.setCursor(130, 80);
    tft.println("Test");

    tft.setCursor(30, 110);
    tft.setTextSize(3);
    tft.println("Press to Start!");
  }
}