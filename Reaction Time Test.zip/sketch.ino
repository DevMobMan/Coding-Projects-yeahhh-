bool Screen = false;
#include <SPI.h>
#define TFT_DC 9
#define TFT_CS 10
#define TFT_RST 8
#include "Adafruit_GFX.h"
#include "Adafruit_ILI9341.h"
bool gone = false;
unsigned long startTime = 0;
unsigned long endTime = 0;
unsigned long duration = 0;
int butt = 3;
unsigned long CM = 0;
unsigned long PM = 0;
unsigned long RI = 0;
const long minTime = 2000;
const long maxTime = 8000;
void Start();
bool Started = false;
bool PlayerTimeYeah = false;
void RT();
void Start();
void PlayerTime();
void stasis();

Adafruit_ILI9341 tft = Adafruit_ILI9341(TFT_CS, TFT_DC, TFT_RST);

bool isTiming = false;

void setup() {
  tft.begin();
  Serial.begin(9600);
  tft.setRotation(1); 
  randomSeed(analogRead(A0));
  pinMode(butt, INPUT_PULLUP);

  // 1. Fill the background with dark blue
  tft.fillScreen(ILI9341_NAVY);

  // 2. Draw a yellow rectangle frame
  tft.drawRect(10, 10, 300, 220, ILI9341_YELLOW);
  randomSeed(analogRead(A0));
}

void loop() {
  Start();
  
  if (digitalRead(butt) == LOW) {
    if (!Started) {
      Started = true;
      
      // CRUCIAL: Wait right here until you let go of the button 
      // so your start click doesn't mess up the countdown screen!
      while (digitalRead(butt) == LOW) {
        delay(1);
      }
      
      RT(); // Now safely enter the waiting screen phase
    }
  } else if (PlayerTimeYeah == true) {
    PlayerTime();
  }
}
