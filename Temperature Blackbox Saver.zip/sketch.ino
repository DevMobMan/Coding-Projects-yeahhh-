#include <LiquidCrystal.h> 
#include "Adafruit_GFX.h" 
#include "Adafruit_ILI9341.h" 
#include <EEPROM.h>  
#include <Keypad.h>
#include <Wire.h> 
#include <Adafruit_SSD1306.h>
#include "pitches6741.h"

bool Manual = false; 
const int SENSOR_PIN = A1;  
const float BETA = 3950;    
bool timetoread = false; 
bool timeto = false; 
int HistoryMax;
int HistoryMin;

// Swapped away from hardware TX1/RX1 serial pins
int Lbutton = 11; 
int Rbutton = 12; 
unsigned long timetime = 0; 
unsigned long timetotimeyeah = 0;
bool Serious = false; 
bool Gaming = false; 
unsigned long OtherCurrentTime = 0;
bool timetochange = false;

const int CONFIG_BOX_1 = 0;   
const int CONFIG_BOX_2 = 2;  
int Min = 100; 
int MAX = 255; 
int currentread = 0; 
int liveData = 0; 

#define TFT_DC 9 
#define TFT_CS 10 
#define TFT_RST 7 
Adafruit_ILI9341 tft = Adafruit_ILI9341(TFT_CS, TFT_DC, TFT_RST); 

const byte ROWS = 4; 
const byte COLS = 4; 

byte rowPins[ROWS] = {23, 25, 27, 29}; 
byte colPins[COLS] = {31, 33, 35, 37}; 
char keys[ROWS][COLS] = {   
  {'1', '2', '3', 'A'},   
  {'4', '5', '6', 'B'},   
  {'7', '8', '9', 'C'},   
  {'*', '0', '#', 'D'} 
}; 

const String PASSWORD = "1067135"; 
String input = ""; 
bool Start = false; 
int Winner = 0; 
unsigned long lastime = 0; 
int storagestep = 0; 

// Shifted LCD off pin 8 to remove collision with TFT display lines
LiquidCrystal lcd(32, 5, 4, 3, 2, 6);  

#define SCREEN_WIDTH 128 
#define SCREEN_HEIGHT 64 
const int SWITCH_MOVEMENT = 16; 
const int BUTTON_JUMP = 19; 
const int BuzzerSound = 14; 
const int Level = A0; 
int PotValue = 0; 
bool ToStart = false; 
const int Button = 22; 
const int BuzzerNotes[] = { NOTE_G3, NOTE_C4, NOTE_E5 }; 
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1); 

// GROUND LEVEL 
int worldX = 0; 
int GROUND_X = 128; 
int EXAMPLE_BLOCK = 4; 
int EXAMPLE_BLOCK2 = 30; 
int EXAMPLE_BLOCK3 = 50; 
int EXAMPLE_BLOCK4 = 80; 
int EXAMPLE_BLOCK5 = 100; 
int EXAMPLE_BLOCK6 = 120; 

// Third Level Structures 
int PillarBlock1 = 35; 
int PillarBlock1Y = 30;
int PillarBlock2 = 80; 
int PillarBlock2Y = 64; 

// Fourth Level Contents 
int Asteroid1 = 32; int Asteroid2 = 96; 
int Asteroid1Y = -20; int Asteroid2Y = -20; 
int Asteroid3 = 15; int Asteroid3Y = -20; 
int Asteroid4 = 96; int Asteroid4Y = -20; 
int Asteroid5 = 32; int Asteroid5Y = -20; 
bool Reverse = false; bool Normal = false; bool Accelerate = false; 
const int SLIDER = A3; 
bool Asteroid1ReTrigger = false; bool Asteroid2Trigger = false; 
bool Asteroid3Trigger = false; bool Asteroid4Trigger = false; 
bool Asteroid5Trigger = false; 

// CLIFF LEVEL 
int verticalVelocity = 0; unsigned long previousTime = 0; 
int Cliff_Block1 = 35; int Cliff_Block2 = 60; 
int Cliff_Block3 = 90; int Cliff_Block4 = 116; 
int Intermission_Platform = 0; int GROUNDY = 50; 
bool isJumping = false; bool OnSum = false; 
bool NextLevel = false; bool FirstLevel = false; 
bool ThirdLevel = false; bool FourthLevel = false; 
bool Hub = false; 
int H1 = 36; int H1Y = 24; int H2 = 40; int H2Y = 30; int H3 = 50; int H3Y = 24; 
int U1 = 55; int U1Y = 24; int U2 = 59; int U2Y = 36; int U3 = 69; int U3Y = 24; 
int B_1 = 78; int B1Y = 24; int B2 = 82; int B2Y = 24; int B3 = 88; int B3Y = 26; 
int B4 = 82; int B4Y = 31; int B5 = 88; int B5Y = 33; int B6 = 82; int B6Y = 38; 

// Player 
int playerX = 5; int playerY = 46; 
const int PLAYER_SIZE = 4; 

Keypad keypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS); 

void setup() {      
    Serial.begin(9600);      
    tft.begin();      
    tft.setRotation(1); 
    Wire.begin();      
    
    // Boot the 16x2 text blocks!
    lcd.begin(16, 2); 
    lcd.clear();
    
    randomSeed(analogRead(A0));      
    pinMode(Rbutton, INPUT_PULLUP);      
    pinMode(Lbutton, INPUT_PULLUP);      
    timetoread = true;      
    if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {          
        for (;;);      
    }
    Hub = true;      
    display.clearDisplay();      
    pinMode(BUTTON_JUMP, INPUT_PULLUP);      
    pinMode(SWITCH_MOVEMENT, INPUT_PULLUP);      
    pinMode(BuzzerSound, OUTPUT);      
    pinMode(Button, INPUT_PULLUP);  
    timetotimeyeah = millis();
}


void loop() {   
  if (timetoread == true) { 

    EEPROM.get(CONFIG_BOX_1, HistoryMax); 
    EEPROM.get(CONFIG_BOX_2, HistoryMin);  
    if (HistoryMax <= -1 || HistoryMax > 1023) {
      HistoryMax = 0;
    } 
    if (HistoryMin <= -1 || HistoryMin > 1023) {
      HistoryMin = 1023;
    }
    timetoread = false;   
  }
  
  Password();   
  
  if (Start == true) {     
    if (Gaming == false && Serious == false) {       
      Title();          
    }          
    if (Gaming == true) {              
      Game();              
      Serious = false;          
    }          
    if (Serious == true) {              
      Manual = true;              
      Gaming = false;              
      if (Manual == true) {                  
        Print();   
        Storage();           
      }          
    }
  }
}
