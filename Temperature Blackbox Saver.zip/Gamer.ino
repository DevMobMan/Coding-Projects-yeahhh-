void Game() {
  unsigned long currentTime = millis();
  
  // Run game calculations every 30 milliseconds (~33 frames per second)
  if (currentTime - previousTime >= 60) {
      previousTime = currentTime;
      PotValue = analogRead(Level);
      
      if (digitalRead(Button) == LOW) {
          ToStart = true;
      }
      
      // --- HUB / LEVEL SELECTION STATE ---
      if (Hub == true) {
          display.clearDisplay();
          display.fillRect(H1 , H1Y , 4 , 16 , WHITE);
          display.fillRect(H2 , H2Y , 10 , 4 , WHITE);
          display.fillRect(H3 , H3Y , 4 , 16 , WHITE);
          display.fillRect(U1 , U1Y , 4 , 16 , WHITE);
          display.fillRect(U2 , U2Y , 10 , 4 , WHITE);
          display.fillRect(U3 , U3Y , 4 , 16 , WHITE);
          display.fillRect(B_1 , B1Y , 4 , 16 , WHITE);
          display.fillRect(B2 , B2Y , 9 , 2 , WHITE);
          display.fillRect(B3 , B3Y , 3 , 5 , WHITE);
          display.fillRect(B4 , B4Y , 9, 2 , WHITE);
          display.fillRect(B5 , B5Y , 3 , 5 , WHITE);
          display.fillRect(B6 , B6Y , 9 , 2 , WHITE);
          display.display();
          
          Serial.print("Hub Active - Pot Value: ");
          Serial.println(PotValue);
          
          if (ToStart == true) {
              if (PotValue < 100) {
                  NextLevel = true;
                  FirstLevel = false; ThirdLevel = false; FourthLevel = false;
                  Hub = false; ToStart = false;
                  Serial.println("[LEVEL SWITCH] Entering Side Scriptor (NextLevel)!");
              }
              else if (PotValue >= 100 && PotValue < 400) {
                  FirstLevel = true;
                  NextLevel = false; ThirdLevel = false; FourthLevel = false;
                  Hub = false; ToStart = false;
                  Serial.println("[LEVEL SWITCH] Entering Cliff Phase (FirstLevel)!");
              }
              else if (PotValue >= 500 && PotValue < 900) {
                  ThirdLevel = true;
                  FirstLevel = false; NextLevel = false; FourthLevel = false;
                  Hub = false; ToStart = false;
                  Serial.println("[LEVEL SWITCH] Entering Pillars Phase (ThirdLevel)!");
              }
              else if (PotValue >= 900) {
                  FourthLevel = true;
                  FirstLevel = false; NextLevel = false; ThirdLevel = false;
                  Hub = false; ToStart = false;
                  Serial.println("[LEVEL SWITCH] Entering Asteroid Hazards (FourthLevel)!");
              }
          }
      }
      
      OnSum = false;
      
      // --- FIRST LEVEL (CLIFF PHASE) ---
      if (FirstLevel == true) {
          if (currentTime % 1000 < 30) { Serial.println("Playing Level 1: Cliff Phase..."); }
          if (digitalRead(BUTTON_JUMP) == LOW && isJumping == false) {
              verticalVelocity = -5; 
              tone(BuzzerSound, NOTE_C4, 50);
              isJumping = true;
          }
          if (digitalRead(SWITCH_MOVEMENT) == LOW) {
              Cliff_Block1 -= 2; Cliff_Block2 -= 2; Cliff_Block3 -= 2; Cliff_Block4 -= 2;
              Intermission_Platform -= 2;
          } else {
              Cliff_Block1 += 2; Cliff_Block2 += 2; Cliff_Block3 += 2; Cliff_Block4 += 2;
              Intermission_Platform += 2;
          } 
          
          if (playerY >= 46 && playerX + 4 >= Intermission_Platform && playerX <= Intermission_Platform + 23) {
              OnSum = true;
          } else if (playerY >= 46 && playerX + 4 >= Cliff_Block1 && playerX <= Cliff_Block1 + 12) {
              OnSum = true;
          } else if (playerY >= 46 && playerX + 4 >= Cliff_Block2 && playerX <= Cliff_Block2 + 12) {
              OnSum = true;
          } else if (playerY >= 46 && playerX + 4 >= Cliff_Block3 && playerX <= Cliff_Block3 + 12) {
              OnSum = true;
          } else if (playerY >= 46 && playerX + 4 >= Cliff_Block4 && playerX <= Cliff_Block4 + 12) {
              OnSum = true;
          }
          
          playerY += verticalVelocity;
          if (OnSum == true) {
              playerY = 46; verticalVelocity = 0; isJumping = false;
          } else {
              verticalVelocity += 1;
          }
          
          if (playerY > 48) {
              playerX = 5; playerY = 46; 
              Cliff_Block1 = 35; Cliff_Block2 = 60; Cliff_Block3 = 90; Cliff_Block4 = 116;
              Intermission_Platform = 0;
              tone(BuzzerSound, NOTE_G3, 100);
          }
          if ((Cliff_Block4 + 12) == 0) {
              playerX = 5; playerY = 46;
              Cliff_Block1 = 200; Cliff_Block2 = 200; Cliff_Block3 = 200; Cliff_Block4 = 200;
              Intermission_Platform = 200;
              tone(BuzzerSound, NOTE_G3, 200);
              NextLevel = true; FirstLevel = false;
          }
      }
      
      // --- NEXT LEVEL (SIDE SCRIPTOR) ---
      if (NextLevel == true) {
          if (currentTime % 1000 < 30) { Serial.println("Playing Level 2: Side Scriptor..."); }
          int groundSurface = GROUNDY - PLAYER_SIZE; 
          
          if (digitalRead(BUTTON_JUMP) == LOW && isJumping == false) {
              verticalVelocity = -6; isJumping = true;
              tone(BuzzerSound, NOTE_C4, 50);
          }
          if (digitalRead(SWITCH_MOVEMENT) == LOW) {
              GROUND_X -= 2; EXAMPLE_BLOCK -= 2; EXAMPLE_BLOCK2 -= 2;
              EXAMPLE_BLOCK3 -= 2; EXAMPLE_BLOCK4 -= 2; EXAMPLE_BLOCK5 -= 2; EXAMPLE_BLOCK6 -= 2;
          } else if (digitalRead(SWITCH_MOVEMENT) == HIGH) {
              GROUND_X += 2; EXAMPLE_BLOCK += 2; EXAMPLE_BLOCK2 += 2;
              EXAMPLE_BLOCK3 += 2; EXAMPLE_BLOCK4 += 2; EXAMPLE_BLOCK5 += 2; EXAMPLE_BLOCK6 += 2;
          }
          
          playerY += verticalVelocity; 
          if (playerY > SCREEN_HEIGHT) {
              playerX = 20; playerY = 46; verticalVelocity = 0; isJumping = false;
          }
          if (playerY < groundSurface) {
              verticalVelocity += 1; 
          } else {
              playerY = groundSurface; verticalVelocity = 0; isJumping = false;
          }
          
          if ((playerX + 4 >= EXAMPLE_BLOCK + 60 && playerX <= (EXAMPLE_BLOCK + 69) && playerY + 4 >= 40 && playerY <= 49) || 
              (playerX + 4 >= EXAMPLE_BLOCK2 + 70 && playerX <= (EXAMPLE_BLOCK2 + 79) && playerY + 4 >= 40 && playerY <= 49) || 
              (playerX + 4 >= EXAMPLE_BLOCK3 + 80 && playerX <= (EXAMPLE_BLOCK3 + 89) && playerY + 4 >= 40 && playerY <= 49) || 
              (playerX + 4 >= EXAMPLE_BLOCK4 + 90 && playerX <= (EXAMPLE_BLOCK4 + 99) && playerY + 4 >= 40 && playerY <= 49) || 
              (playerX + 4 >= EXAMPLE_BLOCK5 + 100 && playerX <= (EXAMPLE_BLOCK5 + 109) && playerY + 4 >= 40 && playerY <= 49) || 
              (playerX + 4 >= EXAMPLE_BLOCK6 + 110 && playerX <= (EXAMPLE_BLOCK6 + 119) && playerY + 4 >= 40 && playerY <= 49)) {
              playerX = 20; playerY = 46;
              EXAMPLE_BLOCK = 4; EXAMPLE_BLOCK2 = 30; EXAMPLE_BLOCK3 = 50;
              EXAMPLE_BLOCK4 = 80; EXAMPLE_BLOCK5 = 100; EXAMPLE_BLOCK6 = 120;
              tone(BuzzerSound, NOTE_G3, 200);
          }
          if (playerX > EXAMPLE_BLOCK6 + 110 + 9 + 5) {
              NextLevel = false; ThirdLevel = true; FirstLevel = false;
          }
      }
      // --- THIRD LEVEL (PILLARS PHASE) ---
      if (ThirdLevel == true && NextLevel == false && FirstLevel == false) {
          if (currentTime % 1000 < 30) { Serial.println("Playing Level 3: Pillars Phase..."); }
          playerY = 32;
          verticalVelocity += playerY;
          if (digitalRead(BUTTON_JUMP) == LOW) {
              PillarBlock1Y += 3; PillarBlock2Y += 2;
          } else if (digitalRead(BUTTON_JUMP) == HIGH) {
              PillarBlock1Y -= 3; PillarBlock2Y -= 2;
          }
          if (digitalRead(SWITCH_MOVEMENT) == LOW) {
              PillarBlock1 -= 2; PillarBlock2 -= 2;
          } else if (digitalRead(SWITCH_MOVEMENT) == HIGH) {
              PillarBlock1 += 2; PillarBlock2 += 2;
          }
          if ((playerX + 4 > PillarBlock1 && playerX + 4 < PillarBlock1 + 10 && playerY > PillarBlock1Y && playerY < PillarBlock1Y + 34) || 
              (playerX + 4 > PillarBlock2 && playerX + 4 < PillarBlock2 + 10 && playerY > PillarBlock2Y && playerY < PillarBlock2Y + 34)) {
              playerX = 5; playerY = 32;
              PillarBlock1 = 35; PillarBlock1Y = 30; PillarBlock2 = 80; PillarBlock2Y = 64;
              tone(BuzzerSound, NOTE_G3, 200);
          }
          if (PillarBlock2 < 0) {
              FirstLevel = false; NextLevel = false; ThirdLevel = false; FourthLevel = true;
          }
          
          display.clearDisplay();
          display.fillRect(playerX , playerY , PLAYER_SIZE , PLAYER_SIZE , WHITE);
          display.fillRect(PillarBlock1 , PillarBlock1Y , 10 , 34 , WHITE);
          display.fillRect(PillarBlock2 , PillarBlock2Y , 10 , 34 , WHITE);
          display.display();
      }
      
      // --- FOURTH LEVEL (ASTEROID HAZARDS) ---
      if (FourthLevel == true) {
          if (currentTime % 1000 < 30) { Serial.println("Playing Level 4: Asteroids..."); }
          int SLIDEVAL = analogRead(SLIDER);
          if (SLIDEVAL < 100) {
              Reverse = true; Normal = false; Accelerate = false;
          }
          if (Asteroid1Y > 64) { Asteroid2Trigger = true; Asteroid1ReTrigger = false; }
          if (Asteroid2Y > 64) { Asteroid3Trigger = true; Asteroid2Trigger = false; }
          if (Asteroid3Y > 64) { Asteroid4Trigger = true; Asteroid3Trigger = false; }
          if (Asteroid4Y > 64) { Asteroid5Trigger = true; Asteroid4Trigger = false; }
          if (Asteroid5Y > 64) { Asteroid1ReTrigger = true; Asteroid5Trigger = false; }
          
          if (Asteroid1ReTrigger == true) {
              FourthLevel = false; FirstLevel = true;
          }
          if (SLIDEVAL > 100 && SLIDEVAL < 500) {
              Normal = true; Accelerate = false; Reverse = false;
          }
          if (SLIDEVAL > 500) {
              Reverse = false; Normal = false; Accelerate = true;
          }
          Asteroid1Y += 5;
          if (Asteroid2Trigger == true) { Asteroid2Y += 4; }
          if (Asteroid3Trigger == true) { Asteroid3Y += 4; Asteroid3 += 5; }
          if (Asteroid4Trigger == true) { Asteroid4Y += 4; Asteroid4 -= 5; }
          if (Asteroid5Trigger == true && Asteroid5Y < 10) { Asteroid5Y += 4; Asteroid5 += 5; }
          else if (Asteroid5Y >= 10 && Asteroid5Y < 20) { Asteroid5Y += 4; Asteroid5 -= 5; }
          else if (Asteroid5Y >= 20 && Asteroid5Y < 30) { Asteroid5Y += 4; Asteroid5 += 5; }
          else if (Asteroid5Y > 30 && Asteroid5Trigger == true) { Asteroid5Y += 4; Asteroid5 -= 2; }
          
          if (Accelerate == true) { verticalVelocity = 2; }
          if (Normal == true) { verticalVelocity = 0; }
          if (Reverse == true) { verticalVelocity = -2; }
          playerY += verticalVelocity;
          
          if (digitalRead(SWITCH_MOVEMENT) == HIGH) { playerX += 5; }
          if (digitalRead(SWITCH_MOVEMENT) == LOW) { playerX -= 5; }
          
          if ((playerX > Asteroid1 && playerX < Asteroid1 + 20 && playerY < Asteroid1Y + 20 && playerY > Asteroid1Y) || 
              (playerX + 4 > Asteroid1 && playerX + 4 < Asteroid1 + 20 && playerY < Asteroid1Y + 20 && playerY > Asteroid1Y) || 
              (playerX > Asteroid2 && playerX < Asteroid2 + 20 && playerY < Asteroid2Y + 20 && playerY > Asteroid2Y) || 
              (playerX + 4 > Asteroid2 && playerX + 4 < Asteroid2 + 20 && playerY < Asteroid2Y + 20 && playerY > Asteroid2Y) || 
              (playerX > Asteroid3 && playerX < Asteroid3 + 20 && playerY < Asteroid3Y + 20 && playerY > Asteroid3Y) || 
              (playerX + 4 > Asteroid3 && playerX + 4 < Asteroid3 + 20 && playerY < Asteroid3Y + 20 && playerY > Asteroid3Y) || 
              (playerX > Asteroid4 && playerX < Asteroid4 + 20 && playerY < Asteroid4Y + 20 && playerY > Asteroid4Y) || 
              (playerX + 4 > Asteroid4 && playerX + 4 < Asteroid4 + 20 && playerY < Asteroid4Y + 20 && playerY > Asteroid4Y) || 
              (playerX > Asteroid5 && playerX < Asteroid5 + 20 && playerY < Asteroid5Y + 20 && playerY > Asteroid5Y) || 
              (playerX + 4 > Asteroid5 && playerX + 4 < Asteroid5 + 20 && playerY < Asteroid5Y + 20 && playerY > Asteroid5Y)) {
              Asteroid1Y = -20; Asteroid2Y = -20; Asteroid3Y = -20; Asteroid3 = 15;
              Asteroid4Y = -20; Asteroid4 = 96; Asteroid5 = 32; Asteroid5Y = -20;
              playerX = 64; playerY = 50;
          }
          if (playerX < 0 || playerX + 4 > 128 || playerY + 4 > 64 || playerY < 0) {
              playerX = 64; playerY = 50;
          }
          
          display.clearDisplay();
          display.fillRect(playerX, playerY, 4, 4, WHITE);
          display.fillRect(Asteroid1 , Asteroid1Y , 20 , 20 , WHITE);
          display.fillRect(Asteroid2 , Asteroid2Y, 20 , 20 , WHITE);
          display.fillRect(Asteroid3 , Asteroid3Y , 20 , 20 , WHITE);
          display.fillRect(Asteroid4 , Asteroid4Y , 20 , 20 , WHITE);
          display.fillRect(Asteroid5 , Asteroid5Y , 20 , 20 , WHITE);
          display.display();
      }
      
      // --- DISPLAY DISPATCH DISPLONG GRAPHICS RENDER ---
      if (NextLevel == true && FirstLevel == false && ThirdLevel == false) {
          display.clearDisplay();
          display.fillRect(playerX, playerY, PLAYER_SIZE, PLAYER_SIZE, WHITE);
          display.fillRect(0, GROUNDY, SCREEN_WIDTH, SCREEN_HEIGHT - GROUNDY, WHITE);
          display.fillRect(EXAMPLE_BLOCK + 60, GROUNDY - 10, 9, 10, WHITE);
          display.fillRect(EXAMPLE_BLOCK2 + 70, GROUNDY - 10, 9, 10, WHITE);
          display.fillRect(EXAMPLE_BLOCK3 + 80, GROUNDY - 10, 9, 10, WHITE);
          display.fillRect(EXAMPLE_BLOCK4 + 90, GROUNDY - 10, 9, 10, WHITE);
          display.fillRect(EXAMPLE_BLOCK5 + 100, GROUNDY - 10, 9, 10, WHITE);
          display.fillRect(EXAMPLE_BLOCK6 + 110, GROUNDY - 10, 9, 10, WHITE);
          display.display();
      }
      if (FirstLevel == true && NextLevel == false && ThirdLevel == false) {
          display.clearDisplay();
          display.fillRect(playerX, playerY, PLAYER_SIZE, PLAYER_SIZE, WHITE);
          display.fillRect(Cliff_Block1, GROUNDY, 12, 12, WHITE);
          display.fillRect(Cliff_Block2, GROUNDY, 12, 12, WHITE);
          display.fillRect(Cliff_Block3, GROUNDY, 12, 12, WHITE);
          display.fillRect(Cliff_Block4, GROUNDY, 12, 12, WHITE);
          display.fillRect(Intermission_Platform, GROUNDY, 23, 10, WHITE);
          display.display();
      }
  }
}
