void Password() {   
  char key = keypad.getKey();   
  if (key != NO_KEY) {     
    if (key == '#') {       
      Start = false;       
      input = "";       
      Serial.println("Retry");       
      return;     
    }     
    if (Start) {       
      return;     
    }   
    if (key >= '0' && key <= '9') { 
      input += key;     
      if (input.length() == PASSWORD.length()) {     
        if (input == PASSWORD) {       
          Serial.println("\n[ACCESS GRANTED] Starting system now...");       
          Start = true;                      
        } else {       
          Serial.println("\n[ACCESS DENIED] Incorrect password. Try again:");       
          input = ""; 
        }     
      }   
    } 
  }
}
