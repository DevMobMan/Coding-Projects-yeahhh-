// IMPORTANT: Make sure these variables are declared globally (at the top of your sketch) like this:
// unsigned long lastime = 0;
// unsigned long timetotimeyeah = 0;
// int storagestep = 0;

void Storage() { 
  int value = analogRead(SENSOR_PIN); 
  unsigned long currentTime = millis(); 

  // 1. Update Historical Max/Min limits
  if (Manual == true) { 
    if (currentTime - timetotimeyeah >= 10000) { 
      if (value > HistoryMax) { 
        HistoryMax = value; 
        EEPROM.update(CONFIG_BOX_1, HistoryMax); 
      } 
      if (value < HistoryMin) { 
        HistoryMin = value; 
        EEPROM.update(CONFIG_BOX_2, HistoryMin); 
      } 
      timetotimeyeah = currentTime; 
    } 
  } else { 
    if (value > HistoryMax) { 
      HistoryMax = value; 
      EEPROM.update(CONFIG_BOX_1, HistoryMax); 
    } 
    if (value < HistoryMin) { 
      HistoryMin = value; 
      EEPROM.update(CONFIG_BOX_2, HistoryMin); 
    } 
  }

  // 2. Handle LCD Slideshow (Only runs in Manual Mode)
  if (Manual == true) {
    // If lastime was never set, or currentTime rolled over, this ensures it triggers
    if (currentTime - lastime >= 1000) { 
      lastime = currentTime; // Lock in the new time instantly
      
      lcd.clear(); // Clear the screen ONCE per second right before printing

      if (storagestep == 0) {
        lcd.print("Current Readings");
        storagestep = 1;
      } 
      else if (storagestep == 1) {
        lcd.print(value);
        storagestep = 2;
      } 
      else if (storagestep == 2) {
        lcd.print("Updated Max");
        storagestep = 3;
      } 
      else if (storagestep == 3) {
        lcd.print(HistoryMax);
        storagestep = 4;
      } 
      else if (storagestep == 4) {
        lcd.print("Updated Min");
        storagestep = 5;
      } 
      else if (storagestep == 5) {
        lcd.print(HistoryMin);
        storagestep = 0; // Reset back to step 0
      }
    }
  } else {
    // If we exit manual mode, reset the tracker so it starts fresh next time
    storagestep = 0; 
  }
}
