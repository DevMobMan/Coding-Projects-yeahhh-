void Print() {   
  if (millis() - OtherCurrentTime >= 3000) {
    timetochange = true;
  }
  int randomNum = random(6);   
  if (randomNum == 0 && timetochange == true) {     
    tft.fillScreen(ILI9341_NAVY);     
    tft.setCursor(70, 50);     
    tft.setTextColor(ILI9341_WHITE);     
    tft.setTextSize(2);     
    tft.println("Optimism is");     
    tft.setCursor(60, 70);     
    tft.println("a condition");
    tft.setCursor(60, 90);
    tft.println("of employment.");
    timetochange = false;
    OtherCurrentTime = millis();
  }
  if (randomNum == 1 && timetochange == true) {     
    tft.fillScreen(ILI9341_NAVY);     
    tft.setCursor(70, 50);     
    tft.setTextColor(ILI9341_WHITE);     
    tft.setTextSize(2);     
    tft.println("We know you'll make");     
    tft.setCursor(60, 70);     
    tft.println("the right choice.");
    timetochange = false;
    OtherCurrentTime = millis();   
  }
  if (randomNum == 2 && timetochange == true) {     
    tft.fillScreen(ILI9341_NAVY);     
    tft.setCursor(70, 50);     
    tft.setTextColor(ILI9341_WHITE);     
    tft.setTextSize(2);     
    tft.println("Rest is just");     
    tft.setCursor(60, 70);     
    tft.println("a lagging indicator"); 
    tft.setCursor(60, 90);  
    tft.println("of weakness."); 
    

    timetochange = false;
    OtherCurrentTime = millis(); 
  }
  if (randomNum == 3 && timetochange == true) {     
    tft.fillScreen(ILI9341_NAVY);     
    tft.setCursor(70, 50);     
    tft.setTextColor(ILI9341_WHITE);     
    tft.setTextSize(2);     
    tft.println("Happily consenting");     
    tft.setCursor(60, 70);     
    tft.println("to the future.");   
    timetochange = false;
    OtherCurrentTime = millis();
  }
  if (randomNum == 4 && timetochange == true) {     
    tft.fillScreen(ILI9341_NAVY);     
    tft.setCursor(70, 50);     
    tft.setTextColor(ILI9341_WHITE);     
    tft.setTextSize(2);     
    tft.println("Lean into the");     
    tft.setCursor(60, 70);     
    tft.println("Monday roadmap");   
    timetochange = false;
    OtherCurrentTime = millis();
  }
  if (randomNum == 5 && timetochange == true) {     
    tft.fillScreen(ILI9341_NAVY);     
    tft.setCursor(70, 50);     
    tft.setTextColor(ILI9341_WHITE);     
    tft.setTextSize(2);     
    tft.println("I'm");     
    tft.setCursor(60, 70);     
    tft.println("Lovin' it");  
    timetochange = false;
    OtherCurrentTime = millis(); 
  }
}
