void Title() {
    static bool screenDrawn = false;
    if (!screenDrawn) {
        tft.fillScreen(ILI9341_NAVY);
        tft.setCursor(70, 50);
        tft.setTextColor(ILI9341_WHITE);
        tft.setTextSize(2);
        tft.println("Welcome User");
        tft.setCursor(70, 70);
        tft.println("Select Mode:");
        tft.setCursor(30, 110);
        tft.setTextSize(2);
        tft.println("Left for Manual Viewing");
        tft.setCursor(60, 130);
        tft.setTextSize(2);
        tft.println("Right for Games");
        tft.setCursor(30, 150);
        tft.println("Highest value:");
        tft.setCursor(210, 150);
        tft.println(CONFIG_BOX_1);
        screenDrawn = true;
    }

    if (digitalRead(Lbutton) == LOW) {
        Serious = true;
        Gaming = false;
        screenDrawn = false; // Reset for next time
        // Clear screen here so the next mode can print cleanly
        tft.fillScreen(ILI9341_NAVY); 
        return;
    }
    if (digitalRead(Rbutton) == LOW) {
        Gaming = true;
        Serious = false;
        screenDrawn = false; 
        return;
    }
}
